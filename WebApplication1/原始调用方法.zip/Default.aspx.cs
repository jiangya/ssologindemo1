﻿using System;
using System.IO;
using System.Net;
using NvWa.PaaS.SSO.Client.SSO;
using WebApplication1.Model;

namespace WebApplication1
{
    public partial class Default : System.Web.UI.Page
    {
        private string AppID = "4";
        private string AppKey = "123456";
        private string AppSecret = "123456";
        private string AppCallbackUrl = "http://localhost:5287/Default.aspx";
        private string state = Guid.NewGuid().ToString("N");
        //private string URL_Authorize = "http://localhost:23036/oauth2/Authorize";
        //private string URL_Token = "http://localhost:23036/oauth2/token";
        private string URL_Me = "http://localhost:23036/oauth2/me";
        protected string URL_logout = "http://localhost:23036/oauth2/logout";

        private static readonly string DefaultUserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";

        protected void Page_Load(object sender, EventArgs e)
        {
            OAuth oauth = new OAuth(AppKey, AppSecret, AppCallbackUrl);

            var authenticationUrl =  oauth.GetAuthorizeURL(state);
            Session["requeststate"] = state;

            URL_logout = string.Format("{0}?response_type={1}&client_id={2}&redirect_uri={3}"
                                       , URL_logout
                                       , "code"
                                       , AppID
                                       , Server.UrlEncode(AppCallbackUrl));
            if (!isUserLogin())
            {
                if (string.IsNullOrEmpty(Request.QueryString["code"]))
                {
                    // 用户未登录，跳转至单点登录
                    // Step1：获取Authorization Code
                    Response.Redirect(string.Format("{0}?response_type={1}&client_id={2}&redirect_uri={3}"
                                                    , URL_Authorize
                                                    , "code"
                                                    , AppID
                                                    , Server.UrlEncode(AppCallbackUrl)));
                }
                else
                {
                    //Step2：通过Authorization Code获取Access Token
                    Response.Write("<br>Step2：通过Authorization Code获取Access Token");
                    var code = Request.QueryString["code"];
                    var url = string.Format("{0}?grant_type=authorization_code&client_id={1}&client_secret={2}&code={3}&state={4}&redirect_uri={5}"
                                            , URL_Token
                                            , AppID
                                            , AppKey
                                            , code
                                            , Guid.NewGuid().ToString("N")
                                            , Server.UrlEncode(AppCallbackUrl)
                        );

                    var request = GetHttpRequest(url);
                    Response.Write("<br>服务器返回的消息：" + request);

                    // 解析请求
                    var model_access_token = SerializeHelper.JSONDeserialize<AccessTokenResponse>(request);

                    if (model_access_token == null)
                    {
                        Response.Write("<br>返回数据错误！");
                        return;
                    }
                    if (model_access_token.code > 0)
                    {
                        Response.Write("<br>服务器返回的消息：" + model_access_token.code_description);
                        return;
                    }

                    // todo Token保存处理

                    //Step3：使用Access Token来获取用户的OpenID
                    Response.Write("<br>Step3：使用Access Token来获取用户的OpenID");
                    url = string.Format("{0}?access_token={1}"
                                        , URL_Me
                                        , model_access_token.access_token
                        );
                    request = GetHttpRequest(url);
                    Response.Write("<br>服务器返回的消息：" + request);

                    var model_openid = SerializeHelper.JSONDeserialize<OpenIDResponse>(request);

                    // todo 用户OpenID保存处理，登录处理

                    Session["LoginInfo"] = new LoginInfo()
                                               {
                                                   UserName = model_openid.openid
                                               };

                }
            }
            else
            {
                // 用户已登录
                var _logininfo = Session["LoginInfo"] as LoginInfo;
                Response.Write("用户已登录：" + _logininfo.UserName);
            }
        }

        /// <summary>
        /// 执行HTTP请求
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private string GetHttpRequest(string url)
        {
            var _request = WebRequest.Create(url) as HttpWebRequest;
            if (_request != null)
            {
                _request.Method = "GET";
                _request.UserAgent = DefaultUserAgent;
                var _data = _request.GetResponse() as HttpWebResponse;
                if (_data != null)
                {
                    var _reader = new StreamReader(_data.GetResponseStream());
                    string _responseFromServer = _reader.ReadToEnd();
                    return _responseFromServer;
                }
            }
            return null;
        }

        /// <summary>
        /// 用户是否已登录
        /// </summary>
        /// <returns></returns>
        private bool isUserLogin()
        {
            return Session["LoginInfo"] != null;
        }
    }
    /// <summary>
    /// 用户登录信息
    /// </summary>
    public class LoginInfo
    {
        public string UserName { get; set; }
    }

}